sed -i 's/localhost//g' kerberos/index.js kerberos/public/script/script.js kerberos/routes/authenticationRoutes.js kerberos/routes/ticketGenerator.js
sed -i 's/localhost//g' fileServer1/index.js fileServer1/public/script/script.js fileServer1/public/index.html
sed -i 's/localhost//g' fileServer2/index.js fileServer2/public/script/script.js fileServer2/public/index.html
sed -i 's/localhost//g' fileServer3/index.js fileServer3/public/script/script.js fileServer3/public/index.html